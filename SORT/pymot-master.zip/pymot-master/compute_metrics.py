#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri May  8 17:11:33 2020

@author: samarth
"""


from pymot import MOTEvaluation
import json 
import argparse
from importers import MOT_hypo_import
from importers import MOT_groundtruth_import


def compute_metrics(gtFile, hypFile):
	with open(gtFile, 'r') as g:
		groundTruth = json.load(g)[0]
	with open(hypFile, 'r') as h:
		hypothesis = json.load(h)[0]
	evaluator = MOTEvaluation(groundTruth, hypothesis,0.2)
	evaluator.evaluate()
	print(evaluator.getMOTA())
	print(evaluator.getMOTP())
	print(evaluator.getRelativeStatistics())
	print(evaluator.getAbsoluteStatistics())

if __name__ == "__main__":
# """    
#    	parser = argparse.ArgumentParser()
#    	parser.add_argument('-g', '--gtFile', required=True)
#    	parser.add_argument('-p', '--hypFile', required=True)
#    	args = parser.parse_args()
   
#    	print(args.gtFile, args.hypFile)
#    	compute_metrics(args.gtFile, args.hypFile)
# """
	gtFile="groundtruth.json"
	hypFile="hypotheses.json"
	compute_metrics(gtFile, hypFile)
	
	
		
		
		
	